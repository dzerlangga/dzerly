# Dzerly Media Bridge

Ekstensi lokal untuk Dzerly v0.3.0 atau lebih baru. Ekstensi tidak mengunduh atau merekam audio; hanya meneruskan judul lagu, artis, album, posisi, status putar, nama layanan, URL tab, dan ID tab ke aplikasi yang berjalan di komputer yang sama. Metadata diperiksa sekitar setiap 3 detik.

## Pemasangan

1. Ekstrak arsip ekstensi ke folder tetap.
2. Di Chrome, buka `chrome://extensions`; di Edge, buka `edge://extensions`.
3. Aktifkan **Developer mode / Mode pengembang**.
4. Pilih **Load unpacked / Muat yang belum dikemas** dan pilih folder yang berisi `manifest.json`.
5. Pastikan Dzerly v0.3.0 atau lebih baru terbuka, lalu putar lagu pada tab layanan yang didukung.

Mendukung Spotify Web, YouTube, YouTube Music, SoundCloud, Apple Music, Deezer, Amazon Music, dan Tidal. Tab perlu menerbitkan metadata media standar atau memiliki elemen audio/video yang dapat dibaca. Aplikasi desktop native dan situs lain yang tidak mengekspos metadata tidak terdeteksi otomatis.

URL tab dikirim hanya melalui koneksi localhost ke aplikasi Dzerly. Aplikasi menyimpannya lokal hanya jika lagu ditambahkan ke antrean. Tombol ▶ antrean membuka URL menggunakan browser default; autentikasi serta pemutaran tetap dilakukan layanan aslinya.
