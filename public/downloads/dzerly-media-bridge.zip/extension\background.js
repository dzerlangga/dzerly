chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== 'sakina-media' || !sender?.tab?.url) return;
  const allowedHosts = [
    'open.spotify.com', 'www.youtube.com', 'music.youtube.com', 'soundcloud.com',
    'music.apple.com', 'www.deezer.com', 'music.amazon.com', 'tidal.com'
  ];
  let host = '';
  try { host = new URL(sender.tab.url).hostname; } catch { return; }
  if (!allowedHosts.includes(host)) return;

  fetch('http://127.0.0.1:17843/media', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...(message.payload || {}), sourceId: String(sender.tab.id) }),
    cache: 'no-store'
  }).catch(() => {
    // Dzerly may be closed; do not keep retrying in the background.
  });
});
