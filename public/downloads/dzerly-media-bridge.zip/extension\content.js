let lastSentKey = '';
let lastSentAt = 0;
let lastTrack = null;
let lastDomPosition = null;

function text(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function metaContent(selector) {
  return document.querySelector(selector)?.getAttribute('content') || '';
}

function activeMediaElement() {
  return [...document.querySelectorAll('audio, video')]
    .filter((element) => !element.paused && !element.ended && Number.isFinite(element.currentTime))
    .sort((a, b) => (b.currentTime || 0) - (a.currentTime || 0))[0] || null;
}

function siteName() {
  const host = location.hostname.replace(/^www\./, '').toLowerCase();
  if (host.includes('spotify')) return 'Spotify Web';
  if (host.includes('youtube')) return host.startsWith('music.') ? 'YouTube Music' : 'YouTube';
  if (host.includes('soundcloud')) return 'SoundCloud';
  if (host.includes('apple')) return 'Apple Music';
  if (host.includes('deezer')) return 'Deezer';
  if (host.includes('amazon')) return 'Amazon Music';
  if (host.includes('tidal')) return 'Tidal';
  return host;
}

function parseClock(value) {
  const raw = text(value);
  if (!/^-?\d{1,2}(:\d{2}){1,2}$/.test(raw)) return null;
  const negative = raw.startsWith('-');
  const seconds = raw.replace('-', '').split(':').map(Number).reduce((total, part) => total * 60 + part, 0);
  return { seconds, negative };
}

// Spotify Web memutar audio lewat elemen media yang tidak berada di DOM, sehingga
// posisi lagu dibaca dari teks waktu di progress bar ("1:19" / "3:41" atau "-2:22").
function domPlaybackTimes() {
  const position = parseClock(document.querySelector('[data-testid="playback-position"]')?.textContent);
  if (!position) return null;
  const end = parseClock(document.querySelector('[data-testid="playback-duration"]')?.textContent);
  let duration = 0;
  if (end) duration = end.negative ? position.seconds + end.seconds : end.seconds;
  return { position: position.seconds, duration };
}

function readTrack() {
  const session = navigator.mediaSession;
  const metadata = session?.metadata;
  const element = activeMediaElement();
  const title = text(metadata?.title)
    || text(metaContent('meta[property="og:title"]'))
    || text(document.querySelector('[data-testid="context-item-link"]')?.textContent)
    || text(document.title.replace(/\s*[|·-]\s*(YouTube|Spotify|SoundCloud|Apple Music).*$/i, ''));
  const artist = text(metadata?.artist)
    || text(metaContent('meta[name="music:musician"]'))
    || text(metaContent('meta[property="music:musician"]'))
    || text(document.querySelector('[data-testid="track-info-artist"]')?.textContent)
    || text(document.querySelector('ytd-video-owner-renderer #channel-name a')?.textContent);
  const album = text(metadata?.album) || text(metaContent('meta[name="music:album"]'));
  const playing = session?.playbackState === 'playing' || Boolean(element);
  const hasMetadata = Boolean(title && (metadata || element || session?.playbackState));
  if (!hasMetadata) return null;
  const domTimes = element ? null : domPlaybackTimes();
  // Spotify Web tidak mengisi mediaSession.playbackState dan elemen audionya
  // tidak ada di DOM. Anggap diputar bila tombol menampilkan "Pause/Jeda"
  // atau bila posisi lagu maju sejak pembacaan sebelumnya.
  let domPlaying = false;
  if (domTimes) {
    const toggle = document.querySelector('[data-testid="control-button-playpause"]');
    const label = text(toggle?.getAttribute('aria-label'));
    const advanced = lastDomPosition !== null && domTimes.position > lastDomPosition && domTimes.position - lastDomPosition <= 10;
    domPlaying = /pause|jeda/i.test(label) || advanced;
    lastDomPosition = domTimes.position;
  }
  const isPlaying = playing || domPlaying;
  return {
    title,
    artist,
    album,
    source: siteName(),
    url: location.href,
    playing: isPlaying,
    duration: element && Number.isFinite(element.duration) ? element.duration : domTimes?.duration || 0,
    position: element ? element.currentTime : domTimes?.position || 0
  };
}

function send(payload) {
  try {
    chrome.runtime.sendMessage({ type: 'sakina-media', payload });
  } catch { /* Extension may be reloaded while a tab stays open. */ }
}

function poll() {
  const track = readTrack();
  if (!track) {
    if (lastTrack) {
      send({ title: '', artist: '', source: siteName(), playing: false, duration: 0, position: 0 });
      lastTrack = null;
      lastSentKey = '';
    }
    return;
  }
  const key = [track.title, track.artist, track.album, track.playing].join('|');
  const now = Date.now();
  if (key !== lastSentKey || now - lastSentAt >= 2800) {
    send(track);
    lastSentKey = key;
    lastSentAt = now;
  }
  lastTrack = track;
}

poll();
setInterval(poll, 3000);
